# Исходники платформы «Пивка для рывка» — для переноса в новый проект

Что внутри:
- index.html, order.html, edit.html — витрина, страница заказа, изменение заказа
- js/ — логика сайта (store.js — витрина и оформление, i18n.js — переводы, track.js — статусы, chat.js — чат, pwa.js — установка на телефон, intro.js — шторка)
- admin/, courier/ — админка и старая страница курьера
- game/, js/game/ — игра «Рывок»
- qr/, print/ — QR-постеры и страница-тизер «Поймай друга»
- manifest.json, sw.js, assets/pwa/ — установка на телефон
- assets/ — картинки (товары, категории, звуки) — бренд «Пивки», для нового сайта заменить
- supabase/migrations/ — вся база по порядку (применять по имени файла)
- supabase/functions/ — Telegram-бот (telegram), игра (game-run), голосовой продавец (voice-session)
- .github/workflows/ — автодеплой сайта и функций
- config.example.js — заполнить и переименовать в config.js (URL проекта Supabase и публичный anon-ключ)
- ТЗ — файл TZ-platforma-dostavki.md рядом

Чего НЕТ (специально):
- config.js с ключами, секреты бота, сервисный ключ Supabase — создаются заново в новом проекте
- промо-видео (promo/), домен (CNAME)
- данные клиентов и заказов

Важно: часть таблиц (products, orders, customers, drivers, store_events, order_ratings и др.) создавалась
в самом начале вне файлов миграций. Для нового проекта попросите разработчика снять схему из
действующей базы (Supabase → Database → Backups / `supabase db dump --schema-only`) или создать
таблицы по разделу «Модель данных» в ТЗ, а затем применить миграции.
