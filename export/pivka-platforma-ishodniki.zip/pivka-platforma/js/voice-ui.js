/* Voice seller — the button on the home screen and the voice sheet.
   Progressive enhancement: if this file or the AI fails, nothing else on the page changes. The sheet reuses the
   site's .overlay/.sheet styles; texts are in RU/KA/HY (follow the site language). */
(function () {
  'use strict';
  const L = () => (document.documentElement.lang || 'ru');
  const TXT = {
    ru: {
      note: 'У меня на тебя пара минут — я тут всем нравлюсь 😉 Не успеем — допиши текстом или собери сам.',
      cta: 'Поговори с Аней', ctaSub: 'Официантка. Скажи, что хочешь — я слушаю', title: 'Аня — официантка «Пивка для рывка»',
      ready: 'Нажми и говори', connecting: 'Подхожу к столику…', listening: 'Говори, я тебя слушаю', thinking: 'Подбираю…', speaking: 'Отвечаю…', reconnecting: 'Связь пропала, восстанавливаю…',
      ready_text: 'Напиши, что нужно', closed: 'Нажми и говори', local: 'Голосом сейчас не получится — пиши, соберу по тексту',
      you: 'Ты', seller: 'Аня', add: 'Добавить', change: 'Изменить', cart: 'Открыть корзину', end: 'Закончить разговор',
      write: '✍️ Или напиши Ане…', send: 'Отправить', total: 'Итого', tryAgain: 'Ещё раз',
      hint: 'Например: «Нас шестеро, бюджет 150 лари, пиво и закуска»', changeHint: 'Скажи или напиши, что поменять: «без рыбы», «пива побольше», «бюджет 100»',
      err: {
        mic_denied: 'Микрофон не разрешён — можно писать.', not_configured: 'Голосом пока не получится — пиши, соберу по тексту.',
        daily_limit: 'Я на сегодня наговорилась, голос сел 🥲 Собери сам — там всё просто, а завтра поболтаем.', rate_limit: 'Дай отдышаться минутку 😅 Или собери сам.',
        new_limit: 'Я на сегодня наговорилась, голос сел 🥲 Собери сам — там всё просто, а завтра поболтаем.',
        openai_quota: 'Голосом сейчас не получится — пиши или собери сам.', network: 'Нет связи с Аней — пиши или собери сам.',
        connection: 'Связь оборвалась. Нажми ещё раз.', default: 'Не получилось подключиться — пиши или собери обычным способом.', no_webrtc: 'Этот браузер не поддерживает голос — пиши.',
      },
      fallback: 'Продолжить обычным способом',
    },
    ka: {
      note: 'შენთვის რამდენიმე წუთი მაქვს — აქ ყველას მოვწონვარ 😉 თუ ვერ მოვასწრებთ, დაწერე ან თავად ააწყე.',
      cta: 'დაელაპარაკე ანის', ctaSub: 'მიმტანი. თქვი, რა გინდა — გისმენ', title: 'ანი — მიმტანი „ლუდი გაქანებისთვის“',
      ready: 'დააჭირე და ილაპარაკე', connecting: 'მაგიდასთან მოვდივარ…', listening: 'ილაპარაკე, გისმენ', thinking: 'ვარჩევ…', speaking: 'გპასუხობ…', reconnecting: 'კავშირი გაწყდა, ვაღდგენ…',
      ready_text: 'დაწერე, რა გჭირდება', closed: 'დააჭირე და ილაპარაკე', local: 'ხმით ახლა ვერ გამოვა — დაწერე, ტექსტით შეგირჩევ',
      you: 'შენ', seller: 'ანი', add: 'დამატება', change: 'შეცვლა', cart: 'კალათის გახსნა', end: 'საუბრის დასრულება',
      write: '✍️ ან მისწერე ანის…', send: 'გაგზავნა', total: 'ჯამი', tryAgain: 'კიდევ ერთხელ',
      hint: 'მაგალითად: „ექვსნი ვართ, ბიუჯეტი 150 ლარია, ლუდი და მისაყოლებელი“', changeHint: 'თქვი ან დაწერე, რა შევცვალო: „თევზის გარეშე“, „მეტი ლუდი“, „ბიუჯეტი 100“',
      err: {
        mic_denied: 'მიკროფონი არ არის ნებადართული — შეგიძლია დაწერო.', not_configured: 'ხმით ჯერ ვერ გამოვა — დაწერე, ტექსტით შეგირჩევ.',
        daily_limit: 'დღეს ბევრი ვილაპარაკე, ხმა ჩამიჯდა 🥲 თავად ააწყე — მარტივია, ხვალ ვისაუბროთ.', rate_limit: 'ერთი წუთით ამოვისუნთქო 😅 ან თავად ააწყე.',
        new_limit: 'დღეს ბევრი ვილაპარაკე, ხმა ჩამიჯდა 🥲 თავად ააწყე — მარტივია, ხვალ ვისაუბროთ.',
        openai_quota: 'ხმით ახლა ვერ გამოვა — დაწერე ან თავად ააწყე.', network: 'ანისთან კავშირი არ არის — დაწერე ან თავად ააწყე.',
        connection: 'კავშირი გაწყდა. კიდევ დააჭირე.', default: 'დაკავშირება ვერ მოხერხდა — დაწერე ან ჩვეულებრივად ააწყე.', no_webrtc: 'ეს ბრაუზერი ხმას არ უჭერს მხარს — დაწერე.',
      },
      fallback: 'ჩვეულებრივად გაგრძელება',
    },
    hy: {
      note: 'Քեզ համար մի քանի րոպե ունեմ — այստեղ բոլորին դուր եմ գալիս 😉 Չհասցնենք՝ գրիր կամ ինքդ հավաքիր։',
      cta: 'Խոսիր Անիի հետ', ctaSub: 'Մատուցողուհի։ Ասա՝ ինչ ես ուզում — լսում եմ', title: 'Անի — մատուցողուհի «Գարեջուր լավ երեկոյի համար»',
      ready: 'Սեղմիր և խոսիր', connecting: 'Գալիս եմ սեղանիդ…', listening: 'Խոսիր, լսում եմ քեզ', thinking: 'Ընտրում եմ…', speaking: 'Պատասխանում եմ…', reconnecting: 'Կապը կտրվեց, վերականգնում եմ…',
      ready_text: 'Գրիր՝ ինչ է պետք', closed: 'Սեղմիր և խոսիր', local: 'Ձայնով հիմա չի ստացվի — գրիր, կհավաքեմ տեքստով',
      you: 'Դու', seller: 'Անի', add: 'Ավելացնել', change: 'Փոխել', cart: 'Բացել զամբյուղը', end: 'Ավարտել զրույցը',
      write: '✍️ Կամ գրիր Անիին…', send: 'Ուղարկել', total: 'Ընդամենը', tryAgain: 'Կրկին',
      hint: 'Օրինակ՝ «Վեց հոգի ենք, բյուջեն 150 լարի է, գարեջուր և խորտիկ»', changeHint: 'Ասա կամ գրիր՝ ինչ փոխել. «առանց ձկան», «ավելի շատ գարեջուր», «բյուջե 100»',
      err: {
        mic_denied: 'Խոսափողը թույլատրված չէ — կարող ես գրել։', not_configured: 'Ձայնով դեռ չի ստացվի — գրիր, կհավաքեմ տեքստով։',
        daily_limit: 'Այսօր շատ խոսեցի, ձայնս նստեց 🥲 Ինքդ հավաքիր — հեշտ է, վաղը կխոսենք։', rate_limit: 'Մի րոպե շունչ քաշեմ 😅 Կամ ինքդ հավաքիր։',
        new_limit: 'Այսօր շատ խոսեցի, ձայնս նստեց 🥲 Ինքդ հավաքիր — հեշտ է, վաղը կխոսենք։',
        openai_quota: 'Ձայնով հիմա չի ստացվի — գրիր կամ ինքդ հավաքիր։', network: 'Անիի հետ կապ չկա — գրիր կամ ինքդ հավաքիր։',
        connection: 'Կապը կտրվեց։ Կրկին սեղմիր։', default: 'Չհաջողվեց միանալ — գրիր կամ հավաքիր սովորական ձևով։', no_webrtc: 'Այս դիտարկիչը ձայն չի աջակցում — գրիր։',
      },
      fallback: 'Շարունակել սովորական ձևով',
    },
  };
  const t = () => TXT[L()] || TXT.ru;
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => Number(n).toFixed(2).replace('.00', '') + ' ₾';
  let mode = 'ai'; // 'ai' | 'local' (no AI: the text field is understood by PivkaVoiceLocal)
  let state = 'closed', errCode = null, lastPainted = null;
  const $ = (id) => document.getElementById(id);

  // The waitress (the girl from the QR teaser) with a small mic badge; she winks now and then.
  const MIC = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" fill="currentColor"><path d="M128,176a48.05,48.05,0,0,0,48-48V64a48,48,0,0,0-96,0v64A48.05,48.05,0,0,0,128,176ZM96,64a32,32,0,0,1,64,0v64a32,32,0,0,1-64,0Zm40,143.6V240a8,8,0,0,1-16,0V207.6A80.11,80.11,0,0,1,48,128a8,8,0,0,1,16,0,64,64,0,0,0,128,0,8,8,0,0,1,16,0A80.11,80.11,0,0,1,136,207.6Z"/></svg>';
  const AVA = '<span class="vface"><img src="assets/voice/ava.jpg" alt="" decoding="async"><img class="w" src="assets/voice/ava-wink.jpg" alt="" decoding="async"></span><span class="vbadge">' + MIC + '</span>';
  function wink(el) { if (!el || el.classList.contains('winking')) return; el.classList.add('winking'); setTimeout(() => el.classList.remove('winking'), 1100) }

  function css() {
    const st = document.createElement('style');
    st.textContent = `
.voiceCta[hidden]{display:none}.voiceCta{display:flex;align-items:center;gap:12px;width:100%;margin-top:10px;padding:12px 14px;border-radius:18px;border:2px solid #ffb51b;background:linear-gradient(135deg,#221a06,#15191b);color:#fff;text-align:left;cursor:pointer}
.voiceCta .vmic{position:relative;flex:0 0 58px;height:58px;border-radius:50%;box-shadow:0 0 0 0 #ffb51b88;animation:vpulse 2.4s infinite}
.vface{position:absolute;inset:0;border-radius:50%;overflow:hidden;border:2px solid #ffb51b;background:#2a2a2a}
.vface img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:opacity .18s}.vface img.w{opacity:0}
.winking .vface img.w{opacity:1}.winking .vface img:not(.w){opacity:0}
.vbadge{position:absolute;right:-3px;bottom:-3px;width:42%;height:42%;min-width:20px;min-height:20px;border-radius:50%;background:#ffb51b;color:#171000;display:grid;place-items:center;border:2px solid #15191b}
.vbadge svg{width:62%;height:62%}
.voiceCta b{display:block;font-size:16px;font-weight:1000}.voiceCta small{display:block;color:#cfd3d6;font-size:13px;margin-top:2px}
@keyframes vpulse{0%{box-shadow:0 0 0 0 #ffb51b77}70%{box-shadow:0 0 0 12px #ffb51b00}100%{box-shadow:0 0 0 0 #ffb51b00}}
@media(prefers-reduced-motion:reduce){.voiceCta .vmic,.vbig.on{animation:none}
.vmic .vic{width:26px;height:26px}#bundlesSection .voiceCta{margin-top:12px}}
#voiceOverlay .sheet{max-height:92vh;overflow:auto}
.vtop{display:flex;align-items:center;justify-content:space-between;gap:10px}.vtop h2{font-size:18px;margin:0}
.vstage{display:flex;flex-direction:column;align-items:center;gap:8px;margin:14px 0 8px}
.vbig{position:relative;width:112px;height:112px;border-radius:50%;border:0;padding:0;background:transparent;cursor:pointer}
.vbig .vface{border-width:3px}.vbig.on .vface{border-color:#22a447}.vbig.on{animation:vgreen 1.6s infinite}.vbig.on .vbadge{background:#22a447;color:#fff}
.vbig.talk .vface{border-color:#ffb51b;box-shadow:0 0 0 4px #ffb51b44}.vbig.wait .vface{border-color:#5b6367}.vbig.wait .vbadge{background:#3a4145;color:#fff}.vbig[disabled]{opacity:.6}
@keyframes vgreen{0%{box-shadow:0 0 0 0 #22a44777}70%{box-shadow:0 0 0 14px #22a44700}100%{box-shadow:0 0 0 0 #22a44700}}
.vnote{color:#8b9296;font-size:12px;text-align:center;max-width:300px;line-height:1.35}.vstatus{font-weight:900;color:#ffcf6b;text-align:center;min-height:20px}.vhint{color:#a9afb3;font-size:13px;text-align:center}
.vmsg{background:#14181a;border:1px solid #272d30;border-radius:14px;padding:10px 12px;margin:8px 0;font-size:14px;line-height:1.4}
.vmsg small{display:block;color:#8b9296;font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px}
.vreco{background:#14181a;border:1px solid #ffb51b66;border-radius:14px;padding:10px 12px;margin:8px 0}
.vreco .line{display:flex;justify-content:space-between;gap:10px;padding:5px 0;border-top:1px solid #23292c;font-size:14px}.vreco .line:first-child{border-top:0}
.vreco .sum{display:flex;justify-content:space-between;font-weight:1000;margin-top:6px}
.vcartbox{border-color:#3ecf8e88}.vcartbox .vct{font-weight:900;font-size:13px;color:#3ecf8e;margin-bottom:2px}.vcartbox .vct+.line{border-top:0}
.vbtns{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0}.vbtns button{border-radius:12px;padding:11px;font-weight:900;border:1px solid #3a4145;background:#1b2022;color:#fff}
.vbtns .yes{background:#ffb51b;color:#171000;border-color:#ffb51b}.vbtns .end{grid-column:1/-1;background:transparent;color:#a9afb3}
.vtext{display:flex;gap:8px;width:100%;margin:10px 0 4px}.vtext input{flex:1;min-width:0;height:54px;padding:0 14px;font-size:17px;border-radius:14px;border:2px solid #ffb51b;background:#0f1214;color:#fff}
.vtext input::placeholder{color:#c9cdd0}.vtext input:focus{outline:none;box-shadow:0 0 0 3px #ffb51b55}
.vtext button{flex:0 0 54px;width:54px;height:54px;border-radius:14px;padding:0;font-size:22px;font-weight:900;background:#ffb51b;color:#171000;border:0}
.verr{color:#ffb4b4;font-size:13px;text-align:center;margin:4px 0}.vfall{display:block;width:100%;margin-top:6px;background:transparent;border:1px dashed #3a4145;color:#ffcf6b;border-radius:12px;padding:10px;font-weight:800}`;
    document.head.appendChild(st);
  }

  function build() {
    // Right under the ready-made «рывки» (index.html #voiceSlot).
    const anchor = $('voiceSlot') || ($('todaySection') && $('todaySection').querySelector('.twoCta'));
    if (!anchor) return false;
    const cta = document.createElement('button');
    cta.type = 'button'; cta.className = 'voiceCta'; cta.id = 'voiceCta';
    cta.innerHTML = '<span class="vmic" aria-hidden="true">' + AVA + '</span><span><b id="vCtaT"></b><small id="vCtaS"></small></span>';
    cta.onclick = open;
    cta.hidden = true; // shown only when the voice seller really works (see available())
    anchor.insertAdjacentElement('afterend', cta);
    const ov = document.createElement('div');
    ov.className = 'overlay'; ov.id = 'voiceOverlay';
    ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true');
    ov.innerHTML = `<div class="sheet"><div class="vtop"><h2 id="vTitle"></h2><button type="button" class="close" aria-label="×" id="vClose">×</button></div>
<div class="vstage"><button type="button" class="vbig" id="vMic" aria-label="mic">${AVA}</button><div class="vstatus" id="vStatus" aria-live="polite"></div><form class="vtext" id="vForm" autocomplete="off"><input id="vInput" maxlength="300" enterkeyhint="send"><button type="submit" id="vSend"></button></form><div class="vhint" id="vHint"></div><div class="vnote" id="vNote"></div></div>
<div class="verr" id="vErr" hidden></div>
<div class="vmsg" id="vUser" hidden><small id="vUserL"></small><span></span></div>
<div class="vmsg" id="vSeller" hidden><small id="vSellerL"></small><span></span></div>
<div class="vreco" id="vReco" hidden></div>
<div class="vreco vcartbox" id="vCartBox" hidden></div>
<div class="vbtns"><button type="button" class="yes" id="vAdd" hidden></button><button type="button" id="vChange" hidden></button><button type="button" id="vCart"></button><button type="button" class="end" id="vEnd"></button></div>
<button type="button" class="vfall" id="vFall" hidden></button></div>`;
    document.body.appendChild(ov);
    $('vClose').onclick = close; $('vEnd').onclick = close;
    $('vMic').onclick = micPress;
    $('vCart').onclick = () => { close(); if (typeof openCart === 'function') openCart() };
    $('vAdd').onclick = addPressed;
    $('vChange').onclick = () => { $('vHint').textContent = t().changeHint; $('vInput').focus() };
    $('vFall').onclick = () => { close(); if (typeof goBuild === 'function') goBuild() };
    $('vForm').onsubmit = (e) => { e.preventDefault(); textSend() };
    ov.addEventListener('click', (e) => { if (e.target === ov) close() });
    // Any other way the sheet gets closed (store.js closeSheet, Escape…) also ends the session.
    new MutationObserver(() => { if (!ov.classList.contains('on') && PivkaVoiceAgent.active()) PivkaVoiceAgent.stop('sheet_closed') }).observe(ov, { attributes: true, attributeFilter: ['class'] });
    return true;
  }

  function texts() {
    const x = t();
    if (!$('voiceCta')) return;
    $('vCtaT').textContent = x.cta; $('vCtaS').textContent = x.ctaSub;
    $('vTitle').textContent = x.title; $('vNote').textContent = x.note || ''; $('vUserL').textContent = x.you; $('vSellerL').textContent = x.seller;
    $('vAdd').textContent = x.add; $('vChange').textContent = x.change; $('vCart').textContent = x.cart; $('vEnd').textContent = x.end;
    $('vInput').placeholder = x.write; $('vSend').textContent = '➤'; $('vSend').setAttribute('aria-label', x.send); $('vFall').textContent = x.fallback;
    if (!$('vHint').dataset.custom) $('vHint').textContent = x.hint;
    paint();
    if (lastReco) renderReco(lastReco);
  }

  function paint() {
    const x = t();
    const s = mode === 'local' ? (errCode ? 'ready_text' : 'local') : state;
    $('vStatus').textContent = x[s] || x.ready;
    const mic = $('vMic');
    mic.classList.toggle('on', state === 'listening');
    mic.classList.toggle('wait', state === 'connecting' || state === 'thinking' || state === 'reconnecting');
    mic.classList.toggle('talk', state === 'speaking');
    if (state === 'listening' && lastPainted !== 'listening') wink(mic); // «говори, я тебя слушаю» — with a wink
    lastPainted = state;
    mic.disabled = mode === 'local' || state === 'connecting' || state === 'reconnecting';
    diagPaint();
    if (errCode) { $('vErr').hidden = false; $('vErr').textContent = x.err[errCode] || x.err.default } else $('vErr').hidden = true;
    $('vFall').hidden = !(mode === 'local' || errCode);
  }

  // ?vdebug=1: the session timeline right in the sheet (event names and timings only) with a copy button.
  function diagPaint() {
    if (!PivkaVoiceAgent.debug) return;
    let box = $('vDiag');
    if (!box) {
      box = document.createElement('div');
      box.innerHTML = '<button type="button" id="vDiagCopy" style="margin:8px 0;border-radius:10px;padding:6px 10px">Copy log</button><pre id="vDiag" style="max-height:180px;overflow:auto;font-size:10px;white-space:pre-wrap;background:#0b0d0e;border-radius:10px;padding:8px"></pre>';
      $('voiceOverlay').querySelector('.sheet').appendChild(box);
      box = $('vDiag');
      $('vDiagCopy').onclick = () => { try { navigator.clipboard.writeText(box.textContent) } catch (e) {} };
      setInterval(diagPaint, 1000);
    }
    box.textContent = PivkaVoiceAgent.diag().map((x) => { const { t: ms, ev, ...rest } = x; return (ms / 1000).toFixed(1) + 's ' + ev + (Object.keys(rest).length ? ' ' + JSON.stringify(rest) : '') }).join('\n');
    box.scrollTop = box.scrollHeight;
  }

  function open() {
    errCode = null;
    try { window.PIVKA_DB && PIVKA_DB.trackEvent('voice_open', { metadata: { lang: L() } }) } catch (e) {}
    if (typeof openSheet === 'function') openSheet('voiceOverlay'); else $('voiceOverlay').classList.add('on');
    paint();
    syncCart();
    if (!window.RTCPeerConnection || !navigator.mediaDevices) { goLocal('no_webrtc'); return }
    if (mode === 'ai' && !PivkaVoiceAgent.active()) startAI(true);
  }
  function close() {
    PivkaVoiceAgent.stop('user');
    if (typeof closeSheet === 'function') closeSheet('voiceOverlay'); else $('voiceOverlay').classList.remove('on');
  }
  async function startAI(withMic) {
    errCode = null;
    const ses = await PivkaVoiceAgent.start({ lang: L(), wantMic: withMic });
    if (!ses && ['not_configured', 'daily_limit', 'new_limit', 'rate_limit', 'openai_quota', 'network', 'openai', 'unavailable', 'session'].includes(errCode)) goLocal(errCode);
  }
  function goLocal(code) {
    mode = 'local';
    if (code) errCode = code;
    state = 'ready_text';
    paint();
  }
  function micPress() {
    if (state === 'speaking') { PivkaVoiceAgent.interrupt(); return }
    if (!PivkaVoiceAgent.active()) startAI(true);
  }
  async function textSend() {
    const v = $('vInput').value.trim();
    if (!v) return;
    $('vInput').value = '';
    if (mode === 'ai' && PivkaVoiceAgent.active() && PivkaVoiceAgent.sendText(v)) return;
    // No AI session: understand it locally with the same tools.
    showUser(v);
    try { window.PIVKA_DB && PIVKA_DB.trackEvent('voice_request', { metadata: { typed: true, local: true, lang: L() } }) } catch (e) {}
    state = 'thinking'; paint();
    const answer = await PivkaVoiceLocal.handle(v, L());
    state = mode === 'local' ? 'ready_text' : 'closed';
    showSeller(answer); paint();
  }
  function addPressed() {
    if (mode === 'ai' && PivkaVoiceAgent.active()) {
      PivkaVoiceAgent.sendText({ ru: 'Да, добавь это в корзину', ka: 'კი, დაამატე კალათაში', hy: 'Այո, ավելացրու զամբյուղ' }[L()] || 'Да, добавь это в корзину');
      return;
    }
    PivkaVoiceTools.run('apply_recommendation', { replace: true }).then((r) => { if (r.ok) showSeller({ ru: 'Добавила. В корзине ', ka: 'დავამატე. კალათაში ', hy: 'Ավելացրի։ Զամբյուղում ' }[L()] + money(r.cart.total)) });
  }
  function showUser(v) { const b = $('vUser'); b.hidden = false; b.querySelector('span').textContent = v }
  function showSeller(v) { const b = $('vSeller'); b.hidden = !v; b.querySelector('span').textContent = v || '' }

  let lastReco = null;
  // What is really in the cart right now (after the seller added / removed / changed something).
  const IN_CART = { ru: '🛒 В корзине', ka: '🛒 კალათაში', hy: '🛒 Զամբյուղում' };
  function renderCartBox(v) {
    const box = $('vCartBox'), btn = $('vCart');
    const items = (v && v.items) || [];
    const lit = L() === 'ka' ? ' ლ' : L() === 'hy' ? ' լ' : ' л';
    if (!items.length && !(v && v.bundle)) { box.hidden = true; btn.textContent = t().cart; return }
    box.innerHTML = `<div class="vct">${IN_CART[L()] || IN_CART.ru}</div>` +
      (v.bundle ? `<div class="line"><span>${esc(v.bundle.name)}</span><b>${money(v.bundle.price)}</b></div>` : '') +
      items.map((i) => `<div class="line"><span>${esc(i.name)} × ${i.quantity}${i.unit === 'L' ? lit : ''}</span><b>${money(i.sum)}</b></div>`).join('') +
      `<div class="sum"><span>${esc(t().total)}</span><span>${money(v.total)}</span></div>`;
    box.hidden = false;
    btn.textContent = t().cart + ' · ' + money(v.total);
  }
  function syncCart() { try { PivkaVoiceTools.run('get_cart', {}).then((r) => renderCartBox(r && (r.cart || r))).catch(() => {}) } catch (e) {} }

  function renderReco(r) {
    lastReco = r;
    const box = $('vReco');
    if (!r || !r.items || !r.items.length) { box.hidden = true; $('vAdd').hidden = true; $('vChange').hidden = true; return }
    const nm = (i) => (i.name_i18n && i.name_i18n[L()]) || i.name;
    box.innerHTML = r.items.map((i) => `<div class="line"><span>${esc(nm(i))} × ${i.quantity}${i.unit === 'liter' ? (L() === 'ka' ? ' ლ' : L() === 'hy' ? ' լ' : ' л') : ''}</span><b>${money(i.sum)}</b></div>`).join('') +
      `<div class="sum"><span>${esc(t().total)}</span><span>${money(r.total)}</span></div>` +
      (r.upgrade ? `<div class="line"><span>${esc({ ru: 'Красивый стол: +', ka: 'სრული სუფრა: +', hy: 'Գեղեցիկ սեղան՝ +' }[L()] || '+')}${r.upgrade.add.map((i) => esc(nm(i)) + ' × ' + i.quantity).join(', ')}</span><b>${money(r.upgrade.total)}</b></div>` : '');
    box.hidden = false; $('vAdd').hidden = false; $('vChange').hidden = false;
  }

  // The button appears only when the server says the voice seller is ready (key set, daily limit not reached).
  // Until the owner adds OPENAI_API_KEY customers see nothing — no half-working feature. ?voice=1 forces it for a test.
  async function available() {
    let force = false;
    try { force = new URLSearchParams(location.search).get('voice') === '1' || sessionStorage.getItem('pivka_voice_force') === '1'; if (force) sessionStorage.setItem('pivka_voice_force', '1') } catch (e) {}
    if (force) return true;
    if (!window.RTCPeerConnection || !navigator.mediaDevices) return false;
    try {
      const url = PIVKA_CONFIG.supabaseUrl.replace(/\/$/, '') + '/functions/v1/voice-session';
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', apikey: PIVKA_CONFIG.supabaseAnonKey }, body: JSON.stringify({ check: true, lang: L() }) });
      const j = await r.json().catch(() => ({}));
      return r.ok && j.public === true; // the owner turns it on for everyone (store_settings «voice»); before that — only ?voice=1
    } catch (e) { return false }
  }

  function init() {
    if (!window.PivkaVoiceAgent || !window.PivkaVoiceTools || !build()) return;
    css();
    PivkaVoiceAgent.on('state', (s) => { state = s; if (s === 'closed' && mode !== 'local') state = 'closed'; paint() });
    PivkaVoiceAgent.on('user', showUser);
    PivkaVoiceAgent.on('seller', (txt) => showSeller(txt));
    PivkaVoiceAgent.on('error', (code) => { errCode = code; paint() });
    PivkaVoiceTools.onChange((ev) => {
      if (ev.type === 'recommendation') renderReco(ev.reco);
      if (ev.type === 'cart') {
        renderCartBox(ev.cart);
        if (lastReco) { $('vAdd').hidden = true; $('vChange').hidden = true; $('vReco').hidden = true } // the suggestion is in the cart now
      }
      if (ev.type === 'checkout') { PivkaVoiceAgent.stop('checkout'); if (typeof closeSheet === 'function') closeSheet('voiceOverlay') }
    });
    texts();
    available().then((yes) => {
      if (!yes) return;
      $('voiceCta').hidden = false;
      // A wink every few seconds on the button; inside the sheet — while she waits for the customer.
      let calm = false;
      try { calm = matchMedia('(prefers-reduced-motion: reduce)').matches } catch (e) {}
      if (!calm) setInterval(() => {
        if (document.hidden) return;
        if ($('voiceOverlay').classList.contains('on')) { if (state === 'listening' || state === 'closed') wink($('vMic')) } else wink($('voiceCta'));
      }, 7000);
    });
    // follow the site language switch
    new MutationObserver(texts).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.PivkaVoiceUI = { open, close, _state: () => ({ mode, state, errCode }) };
})();
