# Pivka v2 — Project Status

## Current checkpoint
Phase 0 audit completed. Phase 1 foundation has started on `pivka-v2`. The production `main` branch has not been changed.

## Phase 1 work completed so far
- Added Supabase/PostgreSQL foundation migration.
- Added roles: OWNER / ADMIN / STAFF / DRIVER.
- Added categories, products/SKUs, customers, addresses, orders, order items and order status history.
- Added inventory movement ledger and expiring stock reservations.
- Added order price/cost snapshots for historical profitability.
- Added RLS foundation and staff access policies.
- Added placeholder seed categories including strong alcohol; no ice category.
- Added configurable draft beer quantity fields; placeholder draft SKU starts at 2 L minimum.
- Added browser data adapter (`js/db.js`) and safe public config template; no secrets committed.
- Added first protected-admin shell/login screen (`admin/index.html`).

## Phase 1 blocked/configuration needed
- A Supabase project must be created/selected and its public URL + anon/publishable key supplied before the database-backed UI can run.
- An OWNER auth user/profile must then be created.
- Real assortment/economics remain pending; placeholder seed values are explicitly marked.

## Existing implementation found
- Static single-page application.
- Main application is contained in `index.html`: HTML, CSS, product data and JavaScript.
- No package.json or application framework detected in the audited paths.
- No backend/database detected.
- Cart exists only in browser memory.
- Age confirmation is stored in localStorage.
- Checkout composes an order and opens WhatsApp.
- Existing upsell modal is hard-coded and is offered only once per session/cart state.
- Existing catalog already has draft beer, packaged beer, fish, chips, snacks and simple ready sets.
- Existing phone/WhatsApp: +995 579 145 634.

## Keep/reuse
- Brand direction and mobile-first visual identity.
- Age gate concept.
- Existing catalog/cart UX as reference.
- Existing WhatsApp fallback ordering path.
- Existing upsell concept, but replace hard-coded SKU popup with data-driven category flow.
- Existing ready sets as seed/reference for the new Bundle/“Рывок” entity.

## Must be rebuilt/added
- Persistent backend/database and admin authentication.
- Product/category/SKU model.
- Inventory ledger + reservations.
- Orders with statuses and price/cost snapshots.
- Real Bundle/“Рывок” engine and bundle builder.
- Gift tiers/progress engine.
- Contextual upsell rules and category drill-down.
- “Спорим на пиво”.
- “Угостить друга”.
- Customers/order history/repeat order.
- Drivers/deliveries/payables.
- Purchases, expenses, finance and daily closing.
- Procurement forecast.
- Analytics events and AI-ready metrics layer.

## Important defects/limitations in current version
- Product data and prices are hard-coded in JavaScript.
- No real stock control.
- Draft beer minimum 2 L is not enforced.
- Ready sets do not consume component inventory because they are ordinary catalog items.
- No order persistence.
- No server-side validation.
- No financial snapshots or COGS.
- Upsell suggestions are fixed SKU IDs and not configurable.
- `upsellOffered` prevents a proper contextual flow after the first offer.
- No payment integration; only cash/transfer labels and WhatsApp handoff.
- No admin panel.

## Implementation plan
- [x] Phase 0 — audit current repository
- [~] Phase 1 — foundation: schema/data layer/admin shell created; needs Supabase project connection, owner bootstrap, order RPC/transaction logic and admin CRUD screens
- [ ] Phase 2 — sales experience: new homepage order, gift progress, Рывки, TOP, catalog, contextual upsell, cart
- [ ] Phase 3 — commercial engine: bundle builder, promotion mechanics, gift tiers, repeat order, product requests
- [ ] Phase 4 — social: beer bet, treat a friend, share links, payment-ready flows
- [ ] Phase 5 — operations: purchases, stock movements, drivers, expenses, daily close, procurement recommendation
- [ ] Phase 6 — analytics/AI-ready layer

## Data still required from owner
Real assortment, purchase prices, selling prices, opening stock, delivery pricing, driver compensation and payment/acquiring fees. Until supplied, use clearly marked placeholders only.

## Handoff rule
Before continuing, read `MASTER_SPEC.md` and this file. Continue from the first incomplete phase. Do not rewrite verified completed phases without a concrete reason. Update this file after each completed checkpoint.

## Checkpoint 2026-09-28 — Рывки, подарки, Кери, фото, шторка
- Рывки считаются динамически (`private.bundle_calc`): обычная стоимость = Σ sale_price × qty (с учётом цены города), цена = обычная − скидка (`bundles.discount_type` FIXED/PERCENT, `discount_value`). `bundles.price`/`compare_at_price` — legacy, новым кодом не читаются (сейчас там переходное зеркало для старой сборки на main).
- Себестоимость/маржа рывка = Σ purchase_price × qty; статус OK / LOW_MARGIN (`min_margin_percent`) / BELOW_COST. Розница никогда не меняется автоматически; `block_below_cost` — ручной выключатель владельца.
- Рывок недоступен, если компонент удалён/выключен/не в городе/нет остатка (только для OWN_STOCK). Замены не подставляются.
- `create_bundle_order(..., p_city, p_items)` создаёт ОДИН заказ: рывок + доп. товары, один подарок на всю корзину; строки поставщикам.
- Подарки: 60 ₾ → DAV-FISH-STR-030, 100 ₾ → DAV-FISH-SIG-001; выдаётся только самый высокий достигнутый уровень.
- Локализация названий товаров: `products.name_i18n` {ka, hy}; `products.name` — RU. Редактируется в админке (Товары).
- Шторка первого экрана: `js/intro.js` + `assets/hero/intro.css` (hold 3000 / reveal 1000, reduced motion 200/250).
- Миграции: `supabase/migrations/20260928_*.sql` (применены в проекте uphnuzgaildmjrttmbaq).

## Checkpoint 2026-10-07 — Голосовой продавец (ветка `feature/voice-seller-trilingual`, не в main)
Архитектурное решение (после аудита):
- Голос: OpenAI Realtime (`gpt-realtime-2.1`) по WebRTC прямо из браузера. Постоянный ключ — только в Supabase Secret
  `OPENAI_API_KEY`; браузер получает одноразовый `ek_…` от функции `voice-session` (домены, лимиты по `store_events`).
- ИИ только понимает речь и выбирает инструмент. Все товары/цены/рывки/подарки/доставка — существующая логика
  `store.js` (общий глобальный scope классических скриптов), без второй формулы цен. Подбор корзины —
  детерминированный `js/recommendation-engine.js`. Заказ отправляет только обычная форма (18+ сохраняется).
- Модули отдельные (`js/voice-*.js`, `js/recommendation-engine.js`); `store.js` не менялся. Без ключа/при ошибке —
  текстовый запасной режим (`js/voice-local.js`) и обычный магазин.
- Новых таблиц и изменений схемы нет. Развёрнута новая функция `voice-session` (verify_jwt=false, своя проверка).
Осталось владельцу: `OPENAI_API_KEY` в Supabase Secrets (см. VOICE_AGENT_SETUP.md).
